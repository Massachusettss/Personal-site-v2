<?php
/**
 * Plugin Name: Karis Theme
 * Plugin URI:  https://themeforest.net/user/v_kulesh/portfolio
 * Description: Core Plugin for Karis Theme.
 * Version:     1.0.0
 * Author:      Vladimir Kulesh
 * Author URI:  https://themeforest.net/user/v_kulesh
 * License:     GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: karis-theme
 */

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Currently plugin version.
 */
define( 'FT_VERSION', '1.0.0' );

/**
 * The core plugin class.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-karis-theme.php';

/**
 * Begins execution of the plugin.
 *
 * @since    1.0.0
 */
function run_karis_theme() {

	new Karis_Theme();

}
run_karis_theme();
