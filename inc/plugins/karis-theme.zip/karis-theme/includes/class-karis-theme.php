<?php
/**
 * The file that defines the core plugin class
 *
 * @package    Karis_Theme
 * @subpackage Karis_Theme/includes
 */

/**
 * The core plugin class.
 */
class Karis_Theme {

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		if ( defined( 'FT_VERSION' ) ) {
			$this->version = FT_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'karis-theme';

		$this->load_dependencies();
		$this->set_metaboxes();
		$this->set_locale();
	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for metaboxes functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-karis-theme-metaboxes.php';

	}

	/**
	 * Define the metaboxes for this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_metaboxes() {

		new Karis_Theme_Metaboxes();

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * @since    1.0.0
	 * @access   public
	 */
	public function set_locale() {

		load_plugin_textdomain(
			'karis-theme',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}

}
