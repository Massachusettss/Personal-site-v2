<?php
/**
 * Define the metaboxes to be used for the posts
 *
 * @package    Karis_Theme
 * @subpackage Karis_Theme/includes
 */

/**
 * Define the metaboxes to be used for the posts.
 *
 * @since      1.0.0
 */
class Karis_Theme_Metaboxes {

	function __construct() {
		add_action( 'add_meta_boxes', array( $this, 'karis_meta_boxes' ) );
		add_action( 'save_post', array( $this, 'save_meta_boxes' ), 10, 2 );
	}

	/**
	 * Register the metaboxes to be used for the posts.
	 */
	function karis_meta_boxes() {
	  $screens = array( 'post' );

	  foreach ( $screens as $screen ) {
	    add_meta_box(
	      'display_location',
	      esc_html__( 'Display Location', 'karis-theme' ),
	      array( $this, 'render_meta_boxes' ),
	      $screen,
	      'side',
	      'default'
	    );
	  }
	}

	/**
	 * Set up metaboxes fields.
	 */
	function meta_boxes_fields() {
		global $display_location_field;

		$display_location_field = array(
			'id'      => 'display_location_select',
			'desc'    => esc_html__( 'Select where do you want to display the entry.', 'karis-theme' ),
			'type'    => 'select',
			'options' => array (
				'1' => array (
					'label' => esc_html__( 'List of entries', 'karis-theme' ),
					'value' => 'list_of_entries'
				),
				'2' => array (
					'label' => esc_html__( 'Featured area', 'karis-theme' ),
					'value' => 'featured_area'
				)
			)
		);
	}

	/**
	 * The HTML for the fields.
	 */
	function render_meta_boxes() {
	  global $post, $display_location_field;

		/**
		 * Get metaboxes fields settings.
		 */
		$this->meta_boxes_fields();

	  wp_nonce_field( basename( __FILE__ ), 'display_location_nonce' );
	  $meta_value = get_post_meta( $post->ID, $display_location_field['id'], true );

	  echo '<p class="description">'.$display_location_field['desc'].'</p>';
	  echo '<select name="'.$display_location_field['id'].'" id="'.$display_location_field['id'].'">';
	  foreach ( $display_location_field['options'] as $option ) {
	    echo '<option', $meta_value == $option['value'] ? ' selected="selected"' : '', ' value="'.$option['value'].'">'.$option['label'].'</option>';
	  }
	  echo '</select>';
	}

	/**
	 * Save metaboxes.
	 */
	function save_meta_boxes( $post_id ) {
	  global $post, $display_location_field;

		/**
		 * Get metaboxes fields settings.
		 */
		$this->meta_boxes_fields();

	  // Verify the nonce before proceeding.
	  if ( ! isset( $_POST[ 'display_location_nonce' ] ) || ! wp_verify_nonce( $_POST[ 'display_location_nonce' ], basename( __FILE__ ) ) ) {
	    return $post_id;
	  }

	  // Stop WP from clearing custom fields on autosave.
	  if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
	    return $post_id;
	  }

    if ( ! current_user_can( 'edit_post', $post_id ) ) {
      return $post_id;
    }

	  if ( ! isset( $_POST[ $display_location_field['id'] ] ) ) {
	    return $post_id;
	  }

	  foreach ( $display_location_field as $field ) {
	    $old = get_post_meta( $post_id, $display_location_field['id'], true );
	    $new = sanitize_text_field( $_POST[ $display_location_field['id'] ] );

	    if ( $new && $new != $old ) {
	      update_post_meta( $post_id, $display_location_field['id'], $new );
	    } elseif ( '' == $new && $old ) {
	      delete_post_meta( $post_id, $display_location_field['id'], $old );
	    }
	  }
	}

}
